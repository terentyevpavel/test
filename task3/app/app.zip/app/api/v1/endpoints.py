"""
API endpoints для работы с заказами
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.db.session import get_db
from app.schemas.order import (
    AddItemToOrderRequest, 
    AddItemToOrderResponse,
    OrderResponse,
    ProductResponse
)
from app.services.order_service import OrderService

router = APIRouter()


@router.post(
    "/orders/{order_id}/items",
    response_model=AddItemToOrderResponse,
    status_code=status.HTTP_200_OK,
    summary="Добавить товар в заказ",
    description="""
    Добавляет товар в существующий заказ.

    **Логика работы:**
    - Если товар уже есть в заказе - увеличивает количество
    - Если товара нет - создает новую позицию
    - Проверяет наличие товара на складе
    - Обновляет остатки товара
    - Пересчитывает итоговую сумму заказа

    **Параметры:**
    - `order_id`: ID заказа
    - `product_id`: ID товара
    - `quantity`: Количество для добавления

    **Возвращает:**
    - Обновленную информацию о заказе

    **Ошибки:**
    - 404: Заказ или товар не найден
    - 400: Недостаточно товара на складе
    - 400: Товар неактивен
    """
)
async def add_item_to_order(
    order_id: int,
    request: AddItemToOrderRequest,
    db: Session = Depends(get_db)
):
    """Добавить товар в заказ"""
    service = OrderService(db)

    try:
        result = service.add_item_to_order(
            order_id=order_id,
            product_id=request.product_id,
            quantity=request.quantity
        )
        return result

    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

    except LookupError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/orders/{order_id}",
    response_model=OrderResponse,
    summary="Получить заказ",
    description="Возвращает информацию о заказе со всеми позициями"
)
async def get_order(order_id: int, db: Session = Depends(get_db)):
    """Получить заказ по ID"""
    service = OrderService(db)

    try:
        order = service.get_order(order_id)
        return order
    except LookupError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/products",
    response_model=List[ProductResponse],
    summary="Список товаров",
    description="Возвращает список всех активных товаров с остатками"
)
async def list_products(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """Получить список товаров"""
    service = OrderService(db)
    products = service.list_products(skip=skip, limit=limit)
    return products


@router.get(
    "/products/{product_id}",
    response_model=ProductResponse,
    summary="Информация о товаре",
    description="Возвращает информацию о товаре и его остатках"
)
async def get_product(product_id: int, db: Session = Depends(get_db)):
    """Получить товар по ID"""
    service = OrderService(db)

    try:
        product = service.get_product(product_id)
        return product
    except LookupError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
