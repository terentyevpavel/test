"""
Pydantic схемы для валидации запросов и ответов
"""

from pydantic import BaseModel, Field, ConfigDict
from decimal import Decimal
from datetime import datetime
from typing import List, Optional


class AddItemToOrderRequest(BaseModel):
    """Запрос на добавление товара в заказ"""
    product_id: int = Field(..., gt=0, description="ID товара")
    quantity: Decimal = Field(..., gt=0, description="Количество товара")

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "product_id": 1,
                "quantity": 2.5
            }
        }
    )


class ProductInfo(BaseModel):
    """Информация о товаре в позиции заказа"""
    id: int
    product_id: int
    product_name: str
    quantity: float
    unit: str
    unit_price: float
    line_total: float


class OrderInfo(BaseModel):
    """Информация о заказе"""
    id: int
    order_number: str
    total_amount: float
    final_amount: float
    items_count: int


class ProductRemaining(BaseModel):
    """Остаток товара на складе"""
    quantity: float
    unit: str


class AddItemToOrderResponse(BaseModel):
    """Ответ при добавлении товара в заказ"""
    success: bool
    action: str = Field(..., description="created или updated")
    message: str
    order: OrderInfo
    item: ProductInfo
    product_remaining: ProductRemaining

    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "success": True,
                "action": "created",
                "message": "Товар 'Ноутбук Lenovo' добавлен в заказ ORD-2025-001",
                "order": {
                    "id": 1,
                    "order_number": "ORD-2025-001",
                    "total_amount": 150000.0,
                    "final_amount": 150000.0,
                    "items_count": 3
                },
                "item": {
                    "id": 5,
                    "product_id": 1,
                    "product_name": "Ноутбук Lenovo",
                    "quantity": 2.0,
                    "unit": "шт",
                    "unit_price": 50000.0,
                    "line_total": 100000.0
                },
                "product_remaining": {
                    "quantity": 8.0,
                    "unit": "шт"
                }
            }
        }
    )


class OrderItemSchema(BaseModel):
    """Схема позиции заказа"""
    id: int
    product_id: int
    product_name: str
    quantity: float
    unit_price: float
    line_total: float

    model_config = ConfigDict(from_attributes=True)


class OrderResponse(BaseModel):
    """Полная информация о заказе"""
    id: int
    order_number: str
    customer_name: str
    order_date: datetime
    status: str
    total_amount: float
    final_amount: float
    items: List[OrderItemSchema]

    model_config = ConfigDict(from_attributes=True)


class ProductResponse(BaseModel):
    """Информация о товаре"""
    id: int
    name: str
    quantity: float
    price: float
    unit: str
    is_active: bool

    model_config = ConfigDict(from_attributes=True)
