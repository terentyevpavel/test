"""
FastAPI приложение для управления заказами
Сервис добавления товаров в заказ
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.v1 import endpoints
from app.core.config import settings
from app.db.database import engine
from app.models import models

# Создать таблицы в БД (в production используйте Alembic)
models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="""
    REST API для добавления товаров в заказ.

    ## Основные возможности:
    - ✅ Добавление товара в заказ
    - ✅ Автоматическое увеличение количества при повторном добавлении
    - ✅ Проверка наличия товара на складе
    - ✅ Обновление остатков товара
    - ✅ Пересчет итоговой суммы заказа
    """,
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Подключение роутеров
app.include_router(
    endpoints.router,
    prefix="/api/v1",
    tags=["Orders"]
)


@app.get("/", tags=["Root"])
async def root():
    """Корневой эндпоинт"""
    return {
        "message": "Order API Service",
        "version": "1.0.0",
        "docs": "/docs",
        "status": "running"
    }


@app.get("/health", tags=["Health"])
async def health_check():
    """Проверка здоровья сервиса"""
    return {
        "status": "healthy",
        "service": "order-api"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
