"""
Конфигурация приложения
"""

from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Настройки приложения"""

    # Основные настройки
    PROJECT_NAME: str = "Order API Service"
    VERSION: str = "1.0.0"
    DEBUG: bool = True

    # Настройки БД
    DATABASE_URL: str = "postgresql://postgres:postgres@db:5432/erp_db"

    # Для локальной разработки можно использовать SQLite
    # DATABASE_URL: str = "sqlite:///./test.db"

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
