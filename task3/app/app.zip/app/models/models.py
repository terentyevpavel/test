"""
SQLAlchemy модели для заказов и товаров
"""

from sqlalchemy import Column, Integer, BigInteger, String, Numeric, Boolean, DateTime, ForeignKey, CheckConstraint
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.db.database import Base


class Customer(Base):
    __tablename__ = 'customers'

    id = Column(BigInteger, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    email = Column(String(255), index=True)

    orders = relationship("Order", back_populates="customer")


class Product(Base):
    __tablename__ = 'products'

    id = Column(BigInteger, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    quantity = Column(Numeric(15, 3), nullable=False, default=0)
    price = Column(Numeric(15, 2), nullable=False)
    unit = Column(String(50), default='шт')
    is_active = Column(Boolean, default=True, index=True)

    order_items = relationship("OrderItem", back_populates="product")

    __table_args__ = (
        CheckConstraint('quantity >= 0', name='check_product_quantity'),
        CheckConstraint('price >= 0', name='check_product_price'),
    )


class Order(Base):
    __tablename__ = 'orders'

    id = Column(BigInteger, primary_key=True, index=True)
    order_number = Column(String(50), unique=True, nullable=False, index=True)
    customer_id = Column(BigInteger, ForeignKey('customers.id'), nullable=False, index=True)
    order_date = Column(DateTime, default=func.now(), index=True)
    status = Column(String(50), nullable=False, default='новый', index=True)
    total_amount = Column(Numeric(15, 2), default=0)
    final_amount = Column(Numeric(15, 2), default=0)

    customer = relationship("Customer", back_populates="orders")
    items = relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")

    __table_args__ = (
        CheckConstraint("status IN ('новый', 'обработка', 'отправлен', 'доставлен', 'отменен')", 
                       name='check_order_status'),
        CheckConstraint('total_amount >= 0', name='check_total_amount'),
        CheckConstraint('final_amount >= 0', name='check_final_amount'),
    )


class OrderItem(Base):
    __tablename__ = 'order_items'

    id = Column(BigInteger, primary_key=True, index=True)
    order_id = Column(BigInteger, ForeignKey('orders.id', ondelete='CASCADE'), 
                     nullable=False, index=True)
    product_id = Column(BigInteger, ForeignKey('products.id', ondelete='RESTRICT'), 
                       nullable=False, index=True)
    quantity = Column(Numeric(15, 3), nullable=False)
    unit_price = Column(Numeric(15, 2), nullable=False)
    line_total = Column(Numeric(15, 2), nullable=False)

    order = relationship("Order", back_populates="items")
    product = relationship("Product", back_populates="order_items")

    __table_args__ = (
        CheckConstraint('quantity > 0', name='check_item_quantity'),
        CheckConstraint('unit_price >= 0', name='check_unit_price'),
        CheckConstraint('line_total >= 0', name='check_line_total'),
    )
