"""
Бизнес-логика для работы с заказами
"""

from decimal import Decimal
from sqlalchemy.orm import Session, joinedload
from typing import List

from app.models.models import Order, OrderItem, Product


class OrderService:
    """Сервис для работы с заказами"""

    def __init__(self, db: Session):
        self.db = db

    def add_item_to_order(
        self,
        order_id: int,
        product_id: int,
        quantity: Decimal
    ) -> dict:
        """
        Добавить товар в заказ

        Args:
            order_id: ID заказа
            product_id: ID товара
            quantity: Количество для добавления

        Returns:
            dict: Информация об обновленном заказе

        Raises:
            LookupError: Если заказ или товар не найден
            ValueError: Если недостаточно товара или товар неактивен
        """
        # Проверить существование заказа
        order = self.db.query(Order).filter(Order.id == order_id).first()
        if not order:
            raise LookupError(f"Заказ с ID {order_id} не найден")

        # Проверить существование товара
        product = self.db.query(Product).filter(Product.id == product_id).first()
        if not product:
            raise LookupError(f"Товар с ID {product_id} не найден")

        # Проверить активность товара
        if not product.is_active:
            raise ValueError(f"Товар '{product.name}' неактивен")

        # Проверить наличие на складе
        if product.quantity < quantity:
            raise ValueError(
                f"Недостаточно товара '{product.name}' на складе. "
                f"Доступно: {product.quantity} {product.unit}, "
                f"Запрошено: {quantity} {product.unit}"
            )

        # Проверить, есть ли товар уже в заказе
        order_item = self.db.query(OrderItem).filter(
            OrderItem.order_id == order_id,
            OrderItem.product_id == product_id
        ).first()

        if order_item:
            # Товар уже есть - увеличить количество
            order_item.quantity += quantity
            order_item.line_total = order_item.quantity * order_item.unit_price
            action = "updated"
        else:
            # Создать новую позицию
            order_item = OrderItem(
                order_id=order_id,
                product_id=product_id,
                quantity=quantity,
                unit_price=product.price,
                line_total=quantity * product.price
            )
            self.db.add(order_item)
            action = "created"

        # Обновить остатки товара
        product.quantity -= quantity

        # Пересчитать итоговую сумму заказа
        self._recalculate_order_totals(order)

        # Сохранить изменения
        self.db.commit()
        self.db.refresh(order)
        self.db.refresh(order_item)
        self.db.refresh(product)

        return {
            "success": True,
            "action": action,
            "message": f"Товар '{product.name}' добавлен в заказ {order.order_number}",
            "order": {
                "id": order.id,
                "order_number": order.order_number,
                "total_amount": float(order.total_amount),
                "final_amount": float(order.final_amount),
                "items_count": len(order.items)
            },
            "item": {
                "id": order_item.id,
                "product_id": product.id,
                "product_name": product.name,
                "quantity": float(order_item.quantity),
                "unit": product.unit,
                "unit_price": float(order_item.unit_price),
                "line_total": float(order_item.line_total)
            },
            "product_remaining": {
                "quantity": float(product.quantity),
                "unit": product.unit
            }
        }

    def _recalculate_order_totals(self, order: Order) -> None:
        """Пересчитать итоговые суммы заказа"""
        total = sum(item.line_total for item in order.items)
        order.total_amount = total
        order.final_amount = total

    def get_order(self, order_id: int) -> Order:
        """Получить заказ по ID"""
        order = self.db.query(Order).options(
            joinedload(Order.items).joinedload(OrderItem.product),
            joinedload(Order.customer)
        ).filter(Order.id == order_id).first()

        if not order:
            raise LookupError(f"Заказ с ID {order_id} не найден")

        return order

    def get_product(self, product_id: int) -> Product:
        """Получить товар по ID"""
        product = self.db.query(Product).filter(Product.id == product_id).first()

        if not product:
            raise LookupError(f"Товар с ID {product_id} не найден")

        return product

    def list_products(self, skip: int = 0, limit: int = 100) -> List[Product]:
        """Получить список товаров"""
        return self.db.query(Product).filter(
            Product.is_active == True
        ).offset(skip).limit(limit).all()
